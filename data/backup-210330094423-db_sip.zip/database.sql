#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id_user` varchar(16) NOT NULL,
  `id_akses` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `nip` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_user`) USING BTREE,
  KEY `username` (`username`) USING BTREE,
  KEY `id_akses` (`id_akses`) USING BTREE,
  CONSTRAINT `admin_ibfk_1` FOREIGN KEY (`id_akses`) REFERENCES `tbl_akses` (`id_akses`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `admin` (`id_user`, `id_akses`, `username`, `password`, `nama`, `nip`, `email`, `created_at`, `updated_at`, `last_login`) VALUES ('fi7js8XE0cp46ZCl', 5, 'kejaksaan', '117a78d988cf9dd02f0b849ddc457232', 'aaaaaaaaaa', '1212121212121212121', 'pm@pn.com', '2021-01-06 10:18:55', NULL, '2021-01-22 05:01:26');
INSERT INTO `admin` (`id_user`, `id_akses`, `username`, `password`, `nama`, `nip`, `email`, `created_at`, `updated_at`, `last_login`) VALUES ('kfOB4iuP5lE01nab', 1, 'Admin', 'e10adc3949ba59abbe56e057f20f883e', 'Dede Almustaqim, S.kom', NULL, 'simpel@simpel.com', '2020-08-21 00:00:00', NULL, '2021-03-30 09:43:55');
INSERT INTO `admin` (`id_user`, `id_akses`, `username`, `password`, `nama`, `nip`, `email`, `created_at`, `updated_at`, `last_login`) VALUES ('kSaCrD4AVZpy3zJP', 2, 'AdminEcdp', 'e10adc3949ba59abbe56e057f20f883e', 'Dede Almustaqim', '1962042019980310001', 'simpel@simpel.com', '2020-08-21 00:00:00', '2021-01-06 09:28:49', '2021-01-22 07:31:22');
INSERT INTO `admin` (`id_user`, `id_akses`, `username`, `password`, `nama`, `nip`, `email`, `created_at`, `updated_at`, `last_login`) VALUES ('mSaCrD4A1Zpy3zJP', 3, 'VerifikatorEcdp', 'e10adc3949ba59abbe56e057f20f883e', 'PANMUD PIDANA', '1111111111111111111', 'edit@simpel.com', '2020-08-21 00:00:00', '2020-10-14 15:36:00', '2020-12-01 10:53:50');
INSERT INTO `admin` (`id_user`, `id_akses`, `username`, `password`, `nama`, `nip`, `email`, `created_at`, `updated_at`, `last_login`) VALUES ('UTArQPgvWi2F6uks', 5, 'kejari_bartim', '0b0bcd2df1518f1cbb06999c3783d3b5', 'Muhammad Noor', '199005272019021002', 'aamnoor89@gmail.com', '2021-01-06 09:28:28', NULL, '2021-01-06 09:32:50');


#
# TABLE STRUCTURE FOR: tbl_akses
#

DROP TABLE IF EXISTS `tbl_akses`;

CREATE TABLE `tbl_akses` (
  `id_akses` int(11) NOT NULL AUTO_INCREMENT,
  `hak_akses` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_akses`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_akses` (`id_akses`, `hak_akses`) VALUES (1, 'Superadmin');
INSERT INTO `tbl_akses` (`id_akses`, `hak_akses`) VALUES (2, 'Adminstrator');
INSERT INTO `tbl_akses` (`id_akses`, `hak_akses`) VALUES (3, 'Verifikator');
INSERT INTO `tbl_akses` (`id_akses`, `hak_akses`) VALUES (4, 'Operator');
INSERT INTO `tbl_akses` (`id_akses`, `hak_akses`) VALUES (5, 'Kejaksaan');


#
# TABLE STRUCTURE FOR: tbl_apbd
#

DROP TABLE IF EXISTS `tbl_apbd`;

CREATE TABLE `tbl_apbd` (
  `id_apdb` int(11) NOT NULL AUTO_INCREMENT,
  `id_bln` int(11) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `pg_apbd` decimal(14,2) DEFAULT '0.00',
  `real_apbd` decimal(14,2) DEFAULT '0.00',
  `real_apbd_per` decimal(5,2) DEFAULT '0.00',
  `real_apbd_fisik` decimal(5,2) DEFAULT '0.00',
  `pg_bl_op` decimal(14,2) DEFAULT '0.00',
  `rk_keu_op_rp` decimal(14,2) DEFAULT '0.00',
  `rk_keu_op_per` decimal(5,2) DEFAULT '0.00',
  `rf_op` decimal(5,2) DEFAULT '0.00',
  `pg_bl_bm` decimal(14,2) DEFAULT '0.00',
  `rk_keu_bm_rp` decimal(14,2) DEFAULT '0.00',
  `rk_keu_bm_per` decimal(5,2) DEFAULT '0.00',
  `rf_bm` decimal(5,2) DEFAULT '0.00',
  `pg_btt` decimal(14,2) DEFAULT '0.00',
  `rk_keu_btt_rp` decimal(14,2) DEFAULT '0.00',
  `rk_keu_btt_per` decimal(5,2) DEFAULT '0.00',
  `rf_btt` decimal(5,2) DEFAULT '0.00',
  `pg_bl_bt` decimal(14,2) DEFAULT '0.00',
  `rk_keu_bt_rp` decimal(14,2) DEFAULT '0.00',
  `rk_keu_bt_per` decimal(14,2) DEFAULT '0.00',
  `rf_bt` decimal(14,2) DEFAULT '0.00',
  `status` int(11) DEFAULT '0',
  PRIMARY KEY (`id_apdb`) USING BTREE,
  KEY `id_bulan` (`id_bln`),
  KEY `id_user` (`id_unit`),
  CONSTRAINT `tbl_apbd_ibfk_1` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_apbd_ibfk_2` FOREIGN KEY (`id_bln`) REFERENCES `tbl_bln` (`id_bln`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_bln
#

DROP TABLE IF EXISTS `tbl_bln`;

CREATE TABLE `tbl_bln` (
  `id_bln` int(11) NOT NULL AUTO_INCREMENT,
  `nm_bln` varchar(255) DEFAULT NULL,
  `tgl_awal` datetime DEFAULT NULL,
  `tgl_akhir` datetime DEFAULT NULL,
  PRIMARY KEY (`id_bln`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (1, 'Januari', '2021-03-29 00:00:00', '2021-04-01 00:00:00');
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (2, 'Februari', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (3, 'Maret', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (4, 'April', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (5, 'Mei', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (6, 'Juni', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (7, 'Juli', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (8, 'Agustus', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (9, 'September', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (10, 'Oktober', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (11, 'November', NULL, NULL);
INSERT INTO `tbl_bln` (`id_bln`, `nm_bln`, `tgl_awal`, `tgl_akhir`) VALUES (12, 'Desember', NULL, NULL);


#
# TABLE STRUCTURE FOR: tbl_pass_log
#

DROP TABLE IF EXISTS `tbl_pass_log`;

CREATE TABLE `tbl_pass_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pass_log` varchar(255) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `dibuat` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_unit` (`id_unit`),
  CONSTRAINT `tbl_pass_log_ibfk_1` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_pass_log` (`id`, `pass_log`, `id_unit`, `dibuat`) VALUES (11, '85b109f2585898e6f1e920b4c4ec6719', 'oysvxho19c0cbc3le3lck6fvq', '2021-03-30');
INSERT INTO `tbl_pass_log` (`id`, `pass_log`, `id_unit`, `dibuat`) VALUES (12, '85b109f2585898e6f1e920b4c4ec6719', NULL, '2021-03-30');


#
# TABLE STRUCTURE FOR: tbl_pemda
#

DROP TABLE IF EXISTS `tbl_pemda`;

CREATE TABLE `tbl_pemda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pemda` varchar(255) DEFAULT NULL,
  `nm_institusi` varchar(255) DEFAULT NULL,
  `nm_pimpinan` varchar(255) DEFAULT NULL,
  `jabatan/gol` varchar(255) DEFAULT NULL,
  `nip` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_pemda` (`id`, `pemda`, `nm_institusi`, `nm_pimpinan`, `jabatan/gol`, `nip`) VALUES (1, 'KABUPATEN BARITO TIMUR', 'BAPPLITBANGDA', 'Ir. FRANZ SILA UTAMA, M.AP', 'Pembina Utama Muda (IV/c)			\r\n', '196702221993081001');


#
# TABLE STRUCTURE FOR: tbl_pendapatan
#

DROP TABLE IF EXISTS `tbl_pendapatan`;

CREATE TABLE `tbl_pendapatan` (
  `id_pd` int(11) NOT NULL AUTO_INCREMENT,
  `id_bln` int(11) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `pad_target` decimal(14,2) DEFAULT '0.00',
  `pad_real` decimal(14,2) DEFAULT '0.00',
  `pad_real_per` decimal(5,2) DEFAULT '0.00',
  `tp_target` decimal(14,2) DEFAULT '0.00',
  `tp_keu` decimal(14,2) DEFAULT '0.00',
  `tp_per` decimal(5,2) DEFAULT '0.00',
  `tad_target` decimal(14,2) DEFAULT '0.00',
  `tad_keu` decimal(14,2) DEFAULT '0.00',
  `tad_per` decimal(5,2) DEFAULT '0.00',
  `pad_sah_target` decimal(14,2) DEFAULT '0.00',
  `pad_sah_keu` decimal(14,2) DEFAULT '0.00',
  `pad_sah_per` decimal(5,2) DEFAULT '0.00',
  `target_total` decimal(14,2) DEFAULT '0.00',
  `keu_total` decimal(14,2) DEFAULT '0.00',
  `keu_per_total` decimal(5,2) DEFAULT '0.00',
  `status_pd` int(11) DEFAULT '0',
  PRIMARY KEY (`id_pd`) USING BTREE,
  KEY `id_bulan` (`id_bln`),
  KEY `id_user` (`id_unit`),
  CONSTRAINT `tbl_pendapatan_ibfk_1` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_pendapatan_ibfk_2` FOREIGN KEY (`id_bln`) REFERENCES `tbl_bln` (`id_bln`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_ppbj_200
#

DROP TABLE IF EXISTS `tbl_ppbj_200`;

CREATE TABLE `tbl_ppbj_200` (
  `id_ppbj_200` int(11) NOT NULL AUTO_INCREMENT,
  `id_bln` int(11) DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `jml_pkt_200` int(11) DEFAULT '0',
  `jml_pg_200` decimal(14,2) DEFAULT '0.00',
  `pl_pkt_200` int(11) DEFAULT '0',
  `pl_rp_200` decimal(14,2) DEFAULT '0.00',
  `h_pl_pkt_200` int(11) DEFAULT '0',
  `h_pl_rp_200` decimal(14,2) DEFAULT '0.00',
  `kontrak_pkt_200` int(11) DEFAULT '0',
  `kontrak_rp_200` decimal(14,2) DEFAULT '0.00',
  `st_pkt_200` int(11) DEFAULT '0',
  `st_rp_200` decimal(14,2) DEFAULT '0.00',
  `bp_pkt_200` int(11) DEFAULT '0',
  `bp_rp_200` decimal(14,2) DEFAULT '0.00',
  `status_ppbj_200` int(11) DEFAULT '0',
  PRIMARY KEY (`id_ppbj_200`) USING BTREE,
  KEY `tbl_ppbj_50_ibfk_1` (`id_bln`),
  KEY `tbl_ppbj_50_ibfk_2` (`id_unit`),
  CONSTRAINT `tbl_ppbj_200_ibfk_1` FOREIGN KEY (`id_bln`) REFERENCES `tbl_bln` (`id_bln`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_ppbj_200_ibfk_2` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_ppbj_25
#

DROP TABLE IF EXISTS `tbl_ppbj_25`;

CREATE TABLE `tbl_ppbj_25` (
  `id_ppbj_25` int(11) NOT NULL AUTO_INCREMENT,
  `id_bln` int(11) DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `jml_pkt_25` int(11) DEFAULT '0',
  `jml_pg_25` decimal(14,2) DEFAULT '0.00',
  `pl_pkt_25` int(11) DEFAULT '0',
  `pl_rp_25` decimal(14,2) DEFAULT '0.00',
  `h_pl_pkt_25` int(11) DEFAULT '0',
  `h_pl_rp_25` decimal(14,2) DEFAULT '0.00',
  `kontrak_pkt_25` int(11) DEFAULT '0',
  `kontrak_rp_25` decimal(14,2) DEFAULT '0.00',
  `st_pkt_25` int(11) DEFAULT '0',
  `st_rp_25` decimal(14,2) DEFAULT '0.00',
  `bp_pkt_25` int(11) DEFAULT '0',
  `bp_rp_25` decimal(14,2) DEFAULT '0.00',
  `status_ppbj_25` int(11) DEFAULT '0',
  PRIMARY KEY (`id_ppbj_25`) USING BTREE,
  KEY `tbl_ppbj_50_ibfk_1` (`id_bln`),
  KEY `tbl_ppbj_50_ibfk_2` (`id_unit`),
  CONSTRAINT `tbl_ppbj_25_ibfk_1` FOREIGN KEY (`id_bln`) REFERENCES `tbl_bln` (`id_bln`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_ppbj_25_ibfk_2` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_ppbj_50
#

DROP TABLE IF EXISTS `tbl_ppbj_50`;

CREATE TABLE `tbl_ppbj_50` (
  `id_ppbj_50` int(11) NOT NULL AUTO_INCREMENT,
  `id_bln` int(11) DEFAULT NULL,
  `tahun` varchar(5) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `jml_pkt_50` int(11) DEFAULT '0',
  `jml_pg_50` decimal(14,2) DEFAULT '0.00',
  `pl_pkt_50` int(11) DEFAULT '0',
  `pl_rp_50` decimal(14,2) DEFAULT '0.00',
  `h_pl_pkt_50` int(11) DEFAULT '0',
  `h_pl_rp_50` decimal(14,2) DEFAULT '0.00',
  `kontrak_pkt_50` int(11) DEFAULT '0',
  `kontrak_rp_50` decimal(14,2) DEFAULT '0.00',
  `st_pkt_50` int(11) DEFAULT '0',
  `st_rp_50` decimal(14,2) DEFAULT '0.00',
  `bp_pkt_50` int(11) DEFAULT '0',
  `bp_rp_50` decimal(14,2) DEFAULT '0.00',
  `status_ppbj_50` int(11) DEFAULT '0',
  PRIMARY KEY (`id_ppbj_50`),
  KEY `tbl_ppbj_50_ibfk_1` (`id_bln`),
  KEY `tbl_ppbj_50_ibfk_2` (`id_unit`),
  CONSTRAINT `tbl_ppbj_50_ibfk_1` FOREIGN KEY (`id_bln`) REFERENCES `tbl_bln` (`id_bln`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_ppbj_50_ibfk_2` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_unit
#

DROP TABLE IF EXISTS `tbl_unit`;

CREATE TABLE `tbl_unit` (
  `id_unit` varchar(25) DEFAULT NULL,
  `nm_unit` varchar(255) DEFAULT NULL,
  `nm_pimpinan` varchar(255) DEFAULT NULL,
  `nip` decimal(50,0) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `gol_jab` varchar(255) DEFAULT NULL,
  `urut` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`urut`),
  KEY `id_unit` (`id_unit`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('oysvxho19c0cbc3le3lck6fvq', 'DINAS PENDIDIKAN', 'Ka Dinas Pendidikan', '0', NULL, NULL, 'Pembina Tingkat I (IV/a)', 1);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('1eg09yr0z50k7wiah26xs53r2', 'DINAS KESEHATAN', NULL, NULL, NULL, NULL, NULL, 2);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('zoi4tf4wof0q0j18srt6m8bpn', 'DINAS PEKERJAAN UMUM, PENATAAN RUANG, PERUMAHAN DAN KAWASAN PERMUKIMAN', NULL, NULL, NULL, NULL, NULL, 3);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('glconi4vv8glpy7wqmp3xxfsm', 'SATUAN POLISI PAMONG PRAJA', NULL, NULL, NULL, NULL, NULL, 4);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('ze1rbuvzygas15fq1i2sfo8lx', 'BADAN PENANGGULANGAN BENCANA DAERAH DAN PEMADAM KEBAKARAN', NULL, NULL, NULL, NULL, NULL, 5);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('sfmnxvhpxwm9wzbcg413c89kn', 'DINAS TENAGA KERJA, TRANSMIGRASI DAN PERINDUSTRIAN', NULL, NULL, NULL, NULL, NULL, 6);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('lwb4h15fr40poh9jvfhn802g2', 'DINAS PEMBERDAYAAN PEREMPUAN, PERLINDUNGAN ANAK DAN KELUARGA BERENCANA', NULL, NULL, NULL, NULL, NULL, 7);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('himfmw96207870dudc524rauq', 'DINAS LINGKUNGAN HIDUP', NULL, NULL, NULL, NULL, NULL, 8);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('b5zsyxurwlndrw8o740c53xc8', 'DINAS KEPENDUDUKAN DAN PENCATATAN SIPIL', NULL, NULL, NULL, NULL, NULL, 9);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('9to2klogkhf4su6ca3y2pc77m', 'DINAS PEMBERDAYAAN MASYARAKAT DAN DESA DAN SOSIAL', NULL, NULL, NULL, NULL, NULL, 10);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('oegc2qtqwuj575594r35ipq9s', 'DINAS PERHUBUNGAN', NULL, NULL, NULL, NULL, NULL, 11);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('tyx91pf6lwi3ohubcoadarob9', 'DINAS KOMUNIKASI, INFORMATIKA, PERSANDIAN DAN STATISTIK', NULL, NULL, NULL, NULL, NULL, 12);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('z7cz7mz0srrqorrk9rdzbsad0', 'DINAS PENANAMAN MODAL DAN PELAYANAN TERPADU SATU PINTU', NULL, NULL, NULL, NULL, NULL, 13);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('uo5sjw1mzpk8h8ji0zc18y26p', 'DINAS KEBUDAYAAN, PARIWISATA, KEPEMUDAAN DAN OLAHRAGA', NULL, NULL, NULL, NULL, NULL, 14);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('x36iigu046976e640owzotbp4', 'DINAS PERPUSTAKAAN DAN KEARSIPAN', NULL, NULL, NULL, NULL, NULL, 15);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('rm9gw82gh6o0atql03fnfa9qz', 'DINAS PERIKANAN DAN PETERNAKAN', NULL, NULL, NULL, NULL, NULL, 16);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('cu2dlzain4fajl9u1u6uyr1by', 'DINAS PERTANIAN DAN KETAHANAN PANGAN', NULL, NULL, NULL, NULL, NULL, 17);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('ym7q2a3fso5mej53idlzsamcs', 'DINAS PERDAGANGAN, KOPERASI DAN USAHA KECIL DAN MENENGAH', NULL, NULL, NULL, NULL, NULL, 18);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('0xsce5ocnfdqiltxjp17zwa3c', 'SEKRETARIAT DAERAH', NULL, NULL, NULL, NULL, NULL, 19);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('6yb3pt98u4tvade6bz427x7f0', 'SEKRETARIAT DEWAN PERWAKILAN RAKYAT DAERAH', NULL, NULL, NULL, NULL, NULL, 20);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('z1esx6y8dx2w3x50871zobvl6', 'BADAN PERENCANAAN PEMBANGUNAN DAN LITBANG DAERAH', NULL, NULL, NULL, NULL, NULL, 21);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('gecrn3mngzsqovwjxuokga30z', 'BADAN PENDAPATAN DAERAH', NULL, NULL, NULL, NULL, NULL, 22);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('wixe80punt9v92xsu3mpepiag', 'BADAN PENGELOLAAN KEUANGAN DAN ASET DAERAH', NULL, NULL, NULL, NULL, NULL, 23);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('med8bztvqdbglq3zpskrelqsr', 'BADAN KEPEGAWAIAN DAN PENGEMBANGAN SUMBER DAYA MANUSIA', NULL, NULL, NULL, NULL, NULL, 24);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('yh558subk9p13cu2pjwiuxvnq', 'INSPEKTORAT', NULL, NULL, NULL, NULL, NULL, 25);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('n7w499b4b042h886s4goa7mf2', 'KECAMATAN DUSUN TENGAH', NULL, NULL, NULL, NULL, NULL, 26);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('fpsdv6271nfjc3othbohp7cqi', 'KECAMATAN PEMATANG KARAU', NULL, NULL, NULL, NULL, NULL, 27);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('wl7551rt2qju7k9sxgamh3d4r', 'KECAMATAN AWANG', NULL, NULL, NULL, NULL, NULL, 28);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('uyi4nwmej2wfa5xamngqqgq3q', 'KECAMATAN PATANGKEP TUTUI', NULL, NULL, NULL, NULL, NULL, 29);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('juk6ze46o9p5ovvw3f2xjtqtg', 'KECAMATAN DUSUN TIMUR', NULL, NULL, NULL, NULL, NULL, 30);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('joc45puwe45mpu3s082c73nhe', 'KECAMATAN BENUA LIMA', NULL, NULL, NULL, NULL, NULL, 31);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('jo2solswp35mkdnd1qva32emi', 'KECAMATAN PAKU', NULL, NULL, NULL, NULL, NULL, 32);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('oows0bm83qjd5gwaxqq8qosgw', 'KECAMATAN PAJU EPAT', NULL, NULL, NULL, NULL, NULL, 33);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('ocy3fg490942qnv6c1x03yo6m', 'KECAMATAN RAREN BATUAH', NULL, NULL, NULL, NULL, NULL, 34);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('ja8bds6lgu26692r9owf7rdta', 'KECAMATAN KARUSEN JANANG', NULL, NULL, NULL, NULL, NULL, 35);
INSERT INTO `tbl_unit` (`id_unit`, `nm_unit`, `nm_pimpinan`, `nip`, `created_at`, `updated_at`, `gol_jab`, `urut`) VALUES ('b05fimavpcnbmq5mztn59gogb', 'BADAN KESATUAN BANGSA DAN POLITIK', NULL, NULL, NULL, NULL, NULL, 36);


#
# TABLE STRUCTURE FOR: tbl_user
#

DROP TABLE IF EXISTS `tbl_user`;

CREATE TABLE `tbl_user` (
  `id_user` varchar(25) NOT NULL,
  `id_akses` int(11) DEFAULT NULL,
  `id_unit` varchar(25) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `last_login` timestamp NULL DEFAULT NULL,
  `nrp_nip` varchar(25) DEFAULT NULL,
  `urut_user` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`urut_user`,`id_user`),
  KEY `username` (`username`) USING BTREE,
  KEY `id_akses` (`id_akses`) USING BTREE,
  KEY `id_unit` (`id_unit`) USING BTREE,
  KEY `id_user` (`id_user`),
  CONSTRAINT `tbl_user_ibfk_1` FOREIGN KEY (`id_akses`) REFERENCES `tbl_akses` (`id_akses`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tbl_user_ibfk_2` FOREIGN KEY (`id_unit`) REFERENCES `tbl_unit` (`id_unit`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('0pGUzNqNt5DpLDPxRxxf7xmXJ', 4, 'oysvxho19c0cbc3le3lck6fvq', '1-1.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-03-30 08:36:03', '', 18);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('ivFlWptE8mGzW5vSpvaA5YKxW', 4, '1eg09yr0z50k7wiah26xs53r2', '1-2.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 19);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('5VYxiKj9QiyHV9sG0JOvNKUXj', 4, 'zoi4tf4wof0q0j18srt6m8bpn', '1-3.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 20);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('K8XQAGlHxo6aoyTHOVVaklPuV', 4, 'glconi4vv8glpy7wqmp3xxfsm', '1-5.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 21);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('RUi5bNXWq8Zq0Zw2eVbrujFza', 4, 'ze1rbuvzygas15fq1i2sfo8lx', '1-5.0-0.0-0.04', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 22);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('1Q0nsbwTL3A5DA5DacZbYnd5e', 4, 'sfmnxvhpxwm9wzbcg413c89kn', '3-31.2-7.0-0.05', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 23);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('k7wU9dxCHiVexzA3AxDgbyfDH', 4, 'lwb4h15fr40poh9jvfhn802g2', '1-2.2-8.2-14.06', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 24);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('qs1BpoYlJslhH4BrkpJpdCYwt', 4, 'himfmw96207870dudc524rauq', '2-11.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 25);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('77iCoUrPtfcP0kLkM2TnRNeDd', 4, 'b5zsyxurwlndrw8o740c53xc8', '2-12.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 26);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('sPhKmja80k3B6JjY7OBMn2k8h', 4, '9to2klogkhf4su6ca3y2pc77m', '1-6.2-13.0-0.05', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 27);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('kFM1YtOf3hdnKXLbzrwJxII88', 4, 'oegc2qtqwuj575594r35ipq9s', '2-15.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 28);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('A2qfFmSSdxWGKfUkPevTjIPXX', 4, 'tyx91pf6lwi3ohubcoadarob9', '2-16.2-20.2-21.04', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 29);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('DPrXNsYHs7X0gKSqqZ28TOnYl', 4, 'z7cz7mz0srrqorrk9rdzbsad0', '2-18.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 30);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('lXo1WLtAk8SHoAWbHqtAVrsnX', 4, 'uo5sjw1mzpk8h8ji0zc18y26p', '2-22.2-19.3-26.04', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 31);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('mk5Ml1dcmo4POakiFdMm89V0J', 4, 'x36iigu046976e640owzotbp4', '2-23.2-24.0-0.02', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 32);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('17yEk3rtaKjvHBgIowg6xDD2I', 4, 'rm9gw82gh6o0atql03fnfa9qz', '3-25.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 33);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('j9TTDV4mzj4qalE1jaAaIykSw', 4, 'cu2dlzain4fajl9u1u6uyr1by', '2-9.3-27.0-0.02', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 34);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('5SB3sXcEKpWvpytLbAW1AhvL5', 4, 'ym7q2a3fso5mej53idlzsamcs', '2-18.2-17.3-30.09', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 35);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('yIkuXtYt0wZox7MZPP8PDzmz0', 4, '0xsce5ocnfdqiltxjp17zwa3c', '4-1.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 36);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('iMkr4o0cz4wM8Bt7LjSFYTaPT', 4, '6yb3pt98u4tvade6bz427x7f0', '4-2.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 37);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('xbPukJ50n9fwjLPiKFd1u9dkh', 4, 'z1esx6y8dx2w3x50871zobvl6', '5-1.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 38);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('On9UPMFQUDmrg3LXzP2BbEdHG', 4, 'gecrn3mngzsqovwjxuokga30z', '5-2.0-0.0-0.03', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 39);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('I549fNgR6IEnNPVbO8KU0Pk4L', 4, 'wixe80punt9v92xsu3mpepiag', '5-2.0-0.0-0.02', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 40);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('rrRIre4nZsTenOTRgMhqHDcKX', 4, 'med8bztvqdbglq3zpskrelqsr', '5-3.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 41);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('ED0cwWCf4guZztKOxK11yzGAB', 4, 'yh558subk9p13cu2pjwiuxvnq', '6-1.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 42);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('GcAFUUBr0o8ipZppQivgAjIgH', 4, 'n7w499b4b042h886s4goa7mf2', '7-1.0-0.0-0.01', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 43);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('bOj6lqY7e5Zu1uUeLjVIuzM14', 4, 'fpsdv6271nfjc3othbohp7cqi', '7-1.0-0.0-0.02', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 44);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('v4nyFJOJMpn7skWY3tcMgtUU5', 4, 'wl7551rt2qju7k9sxgamh3d4r', '7-1.0-0.0-0.03', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 45);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('F6e9GzPgTuHZawVKAoJMUIZAh', 4, 'uyi4nwmej2wfa5xamngqqgq3q', '7-1.0-0.0-0.04', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 46);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('2nCdHYBQeRpcYh0jIb1YkpaaV', 4, 'juk6ze46o9p5ovvw3f2xjtqtg', '7-1.0-0.0-0.05', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 47);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('q7zlTt589h5Jy4IxAPAjOSNUw', 4, 'joc45puwe45mpu3s082c73nhe', '7-1.0-0.0-0.06', '85b109f2585898e6f1e920b4c4ec6719', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 48);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('M6VJygHNnwsa70cpNOi9dJPSp', 4, 'jo2solswp35mkdnd1qva32emi', '7-1.0-0.0-0.07', 'e71103a4767f6a83f50e07c4b587e074', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 49);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('Ce22LmHXWdQsd34DjsNZhbIDS', 4, 'oows0bm83qjd5gwaxqq8qosgw', '7-1.0-0.0-0.08', 'e71103a4767f6a83f50e07c4b587e074', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 50);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('u1ckKtSqWWI3X3NWn5BNlxyhr', 4, 'ocy3fg490942qnv6c1x03yo6m', '7-1.0-0.0-0.09', 'e71103a4767f6a83f50e07c4b587e074', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 51);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('3n6dtt9422ec1Ecqh91TjKfXP', 4, 'ja8bds6lgu26692r9owf7rdta', '7-1.0-0.0-0.10', 'e71103a4767f6a83f50e07c4b587e074', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', 52);
INSERT INTO `tbl_user` (`id_user`, `id_akses`, `id_unit`, `username`, `password`, `nama`, `email`, `created_at`, `updated_at`, `last_login`, `nrp_nip`, `urut_user`) VALUES ('uX7hliqVBSUnU6OfGI55MDGhL', 4, 'b05fimavpcnbmq5mztn59gogb', '1-5.0-0.0-0.03', 'e71103a4767f6a83f50e07c4b587e074', '-', '', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '2021-03-26 10:20:02', '', 53);


